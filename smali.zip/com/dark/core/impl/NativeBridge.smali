.class public Lcom/dark/core/impl/NativeBridge;
.super Ljava/lang/Object;
.source "NativeBridge.java"


# static fields
.field private static sNativeMethodRegistered:Z

.field private static sPageSize:J

.field private static sShellcode:Lcom/dark/core/impl/trampoline/BaseShellcode;

.field private static sTrampolineBase:J

.field private static sTrampolineSetReadOnly:Z


# direct methods
.method static constructor <clinit>()V
    .registers 2

    .line 25
    const-wide/16 v0, 0x0

    sput-wide v0, Lcom/dark/core/impl/NativeBridge;->sPageSize:J

    .line 26
    sput-wide v0, Lcom/dark/core/impl/NativeBridge;->sTrampolineBase:J

    .line 27
    const/4 v0, 0x0

    sput-boolean v0, Lcom/dark/core/impl/NativeBridge;->sNativeMethodRegistered:Z

    .line 28
    sput-boolean v0, Lcom/dark/core/impl/NativeBridge;->sTrampolineSetReadOnly:Z

    .line 29
    const/4 v0, 0x0

    sput-object v0, Lcom/dark/core/impl/NativeBridge;->sShellcode:Lcom/dark/core/impl/trampoline/BaseShellcode;

    return-void
.end method

.method private constructor <init>()V
    .registers 3

    .line 21
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 22
    new-instance v0, Ljava/lang/AssertionError;

    const-string v1, "no instances"

    invoke-direct {v0, v1}, Ljava/lang/AssertionError;-><init>(Ljava/lang/Object;)V

    throw v0
.end method

.method public static getPageSize()J
    .registers 5

    .line 48
    sget-wide v0, Lcom/dark/core/impl/NativeBridge;->sPageSize:J

    .line 49
    .local v0, "ps":J
    const-wide/16 v2, 0x0

    cmp-long v2, v0, v2

    if-nez v2, :cond_3d

    .line 50
    sget v2, Landroid/system/OsConstants;->_SC_PAGESIZE:I

    invoke-static {v2}, Landroid/system/Os;->sysconf(I)J

    move-result-wide v0

    .line 51
    const-wide/16 v2, 0x1000

    cmp-long v2, v0, v2

    if-eqz v2, :cond_3b

    const-wide/16 v2, 0x4000

    cmp-long v2, v0, v2

    if-eqz v2, :cond_3b

    const-wide/32 v2, 0x10000

    cmp-long v2, v0, v2

    if-nez v2, :cond_22

    goto :goto_3b

    .line 52
    :cond_22
    new-instance v2, Ljava/lang/AssertionError;

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "Unexpected page size: "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v0, v1}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-direct {v2, v3}, Ljava/lang/AssertionError;-><init>(Ljava/lang/Object;)V

    throw v2

    .line 54
    :cond_3b
    :goto_3b
    sput-wide v0, Lcom/dark/core/impl/NativeBridge;->sPageSize:J

    .line 56
    :cond_3d
    return-wide v0
.end method

.method public static getShellcode()Lcom/dark/core/impl/trampoline/BaseShellcode;
    .registers 1

    .line 69
    sget-object v0, Lcom/dark/core/impl/NativeBridge;->sShellcode:Lcom/dark/core/impl/trampoline/BaseShellcode;

    if-nez v0, :cond_a

    .line 70
    invoke-static {}, Lcom/dark/core/impl/trampoline/TrampolineCreatorFactory;->create()Lcom/dark/core/impl/trampoline/BaseShellcode;

    move-result-object v0

    sput-object v0, Lcom/dark/core/impl/NativeBridge;->sShellcode:Lcom/dark/core/impl/trampoline/BaseShellcode;

    .line 72
    :cond_a
    sget-object v0, Lcom/dark/core/impl/NativeBridge;->sShellcode:Lcom/dark/core/impl/trampoline/BaseShellcode;

    return-object v0
.end method

.method public static getTrampolineBase()J
    .registers 2

    .line 64
    sget-wide v0, Lcom/dark/core/impl/NativeBridge;->sTrampolineBase:J

    return-wide v0
.end method

.method public static declared-synchronized initializeOnce()V
    .registers 18

    const-class v1, Lcom/dark/core/impl/NativeBridge;

    monitor-enter v1

    .line 76
    :try_start_3
    sget-boolean v0, Lcom/dark/core/impl/NativeBridge;->sNativeMethodRegistered:Z

    const/4 v2, 0x1

    if-nez v0, :cond_a7

    .line 78
    invoke-static {}, Lcom/dark/core/impl/NativeBridge;->getPageSize()J

    move-result-wide v3

    move-wide v7, v3

    .line 80
    .local v7, "pageSize":J
    invoke-static {}, Lcom/dark/core/impl/NativeBridge;->getShellcode()Lcom/dark/core/impl/trampoline/BaseShellcode;

    move-result-object v0

    move-object v3, v0

    .line 81
    .local v3, "shellcode":Lcom/dark/core/impl/trampoline/BaseShellcode;
    invoke-virtual {v3}, Lcom/dark/core/impl/trampoline/BaseShellcode;->generateTrampoline()Lcom/dark/core/impl/trampoline/TrampolineInfo;

    move-result-object v0
    :try_end_16
    .catchall {:try_start_3 .. :try_end_16} :catchall_e5

    move-object v4, v0

    .line 83
    .local v4, "trampoline":Lcom/dark/core/impl/trampoline/TrampolineInfo;
    const/16 v14, 0x20

    .line 86
    .local v14, "MAP_ANONYMOUS":I
    :try_start_19
    sget v0, Landroid/system/OsConstants;->PROT_READ:I

    sget v5, Landroid/system/OsConstants;->PROT_WRITE:I

    or-int/2addr v0, v5

    sget v5, Landroid/system/OsConstants;->PROT_EXEC:I

    or-int v9, v0, v5

    sget v0, Landroid/system/OsConstants;->MAP_PRIVATE:I

    or-int/lit8 v10, v0, 0x20

    const/4 v11, 0x0

    const-wide/16 v12, 0x0

    const-wide/16 v5, 0x0

    invoke-static/range {v5 .. v13}, Landroid/system/Os;->mmap(JJIILjava/io/FileDescriptor;J)J

    move-result-wide v5
    :try_end_2f
    .catch Landroid/system/ErrnoException; {:try_start_19 .. :try_end_2f} :catch_93
    .catchall {:try_start_19 .. :try_end_2f} :catchall_e5

    .line 95
    .local v5, "address":J
    nop

    .line 97
    :try_start_30
    const-string v0, "libcore.io.Memory"

    const-string v9, "pokeByteArray"

    const/4 v10, 0x4

    new-array v10, v10, [Ljava/lang/Class;

    sget-object v11, Ljava/lang/Long;->TYPE:Ljava/lang/Class;

    const/4 v12, 0x0

    aput-object v11, v10, v12

    const-class v11, [B

    aput-object v11, v10, v2

    sget-object v11, Ljava/lang/Integer;->TYPE:Ljava/lang/Class;

    const/4 v13, 0x2

    aput-object v11, v10, v13

    sget-object v11, Ljava/lang/Integer;->TYPE:Ljava/lang/Class;

    const/4 v13, 0x3

    aput-object v11, v10, v13

    .line 99
    invoke-static {v5, v6}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v11

    iget-object v13, v4, Lcom/dark/core/impl/trampoline/TrampolineInfo;->trampolineCode:[B

    invoke-static {v12}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v12

    iget-object v15, v4, Lcom/dark/core/impl/trampoline/TrampolineInfo;->trampolineCode:[B

    array-length v15, v15

    invoke-static {v15}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v15

    filled-new-array {v11, v13, v12, v15}, [Ljava/lang/Object;

    move-result-object v11

    .line 97
    invoke-static {v0, v9, v10, v11}, Lcom/dark/core/impl/ReflectHelper;->invokeStaticMethod(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Class;[Ljava/lang/Object;)Ljava/lang/Object;

    .line 101
    iget-object v0, v4, Lcom/dark/core/impl/trampoline/TrampolineInfo;->nativeEntryOffsetMap:Ljava/util/Map;

    invoke-interface {v0}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_6c
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v9

    if-eqz v9, :cond_8e

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v9

    check-cast v9, Ljava/util/Map$Entry;

    .line 102
    .local v9, "methods":Ljava/util/Map$Entry;, "Ljava/util/Map$Entry<Ljava/lang/reflect/Method;Ljava/lang/Integer;>;"
    invoke-interface {v9}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Ljava/lang/reflect/Method;

    .line 103
    .local v10, "method":Ljava/lang/reflect/Method;
    invoke-interface {v9}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v11

    check-cast v11, Ljava/lang/Integer;

    invoke-virtual {v11}, Ljava/lang/Integer;->intValue()I

    move-result v11

    .line 104
    .local v11, "offset":I
    int-to-long v12, v11

    add-long/2addr v12, v5

    .line 105
    .local v12, "function":J
    invoke-static {v10, v12, v13}, Lcom/dark/core/impl/ArtMethodHelper;->registerNativeMethod(Ljava/lang/reflect/Member;J)V

    .line 106
    .end local v9  # "methods":Ljava/util/Map$Entry;, "Ljava/util/Map$Entry<Ljava/lang/reflect/Method;Ljava/lang/Integer;>;"
    .end local v10  # "method":Ljava/lang/reflect/Method;
    .end local v11  # "offset":I
    .end local v12  # "function":J
    goto :goto_6c

    .line 107
    :cond_8e
    sput-wide v5, Lcom/dark/core/impl/NativeBridge;->sTrampolineBase:J

    .line 108
    sput-boolean v2, Lcom/dark/core/impl/NativeBridge;->sNativeMethodRegistered:Z

    goto :goto_a7

    .line 89
    .end local v5  # "address":J
    :catch_93
    move-exception v0

    .line 90
    .local v0, "e":Landroid/system/ErrnoException;
    iget v2, v0, Landroid/system/ErrnoException;->errno:I

    sget v5, Landroid/system/OsConstants;->EACCES:I

    if-ne v2, v5, :cond_a2

    .line 91
    new-instance v2, Ljava/lang/UnsupportedOperationException;

    const-string v5, "mmap failed with EACCES. Please check SELinux policy for execmem permission."

    invoke-direct {v2, v5}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    throw v2

    .line 94
    :cond_a2
    invoke-static {v0}, Lcom/dark/core/impl/ReflectHelper;->unsafeThrow(Ljava/lang/Throwable;)Ljava/lang/AssertionError;

    move-result-object v2

    throw v2

    .line 110
    .end local v0  # "e":Landroid/system/ErrnoException;
    .end local v3  # "shellcode":Lcom/dark/core/impl/trampoline/BaseShellcode;
    .end local v4  # "trampoline":Lcom/dark/core/impl/trampoline/TrampolineInfo;
    .end local v7  # "pageSize":J
    .end local v14  # "MAP_ANONYMOUS":I
    :cond_a7
    :goto_a7
    sget-boolean v0, Lcom/dark/core/impl/NativeBridge;->sTrampolineSetReadOnly:Z

    if-nez v0, :cond_e3

    .line 117
    sget-wide v3, Lcom/dark/core/impl/NativeBridge;->sTrampolineBase:J

    invoke-static {}, Lcom/dark/core/impl/NativeBridge;->getPageSize()J

    move-result-wide v5

    invoke-static {v3, v4, v5, v6}, Lcom/dark/core/impl/NativeBridge;->nativeClearCache(JJ)V

    .line 119
    invoke-static {}, Lcom/dark/core/impl/NativeBridge;->getPageSize()J

    move-result-wide v3

    move-wide v8, v3

    .line 120
    .local v8, "pageSize":J
    invoke-static {}, Lcom/dark/core/impl/trampoline/CommonSyscallNumberTables;->get()Lcom/dark/core/impl/trampoline/ISyscallNumberTable;

    move-result-object v0
    :try_end_bd
    .catchall {:try_start_30 .. :try_end_bd} :catchall_e5

    move-object v3, v0

    .line 122
    .local v3, "sysnr":Lcom/dark/core/impl/trampoline/ISyscallNumberTable;
    :try_start_be
    invoke-interface {v3}, Lcom/dark/core/impl/trampoline/ISyscallNumberTable;->__NR_mprotect()I

    move-result v5

    sget-wide v6, Lcom/dark/core/impl/NativeBridge;->sTrampolineBase:J

    sget v0, Landroid/system/OsConstants;->PROT_READ:I

    sget v4, Landroid/system/OsConstants;->PROT_EXEC:I

    or-int/2addr v0, v4

    int-to-long v10, v0

    const-wide/16 v14, 0x0

    const-wide/16 v16, 0x0

    const-wide/16 v12, 0x0

    invoke-static/range {v5 .. v17}, Lcom/dark/core/impl/NativeBridge;->nativeSyscall(IJJJJJJ)J

    move-result-wide v4

    .line 124
    .local v4, "rc":J
    const-string v0, "mprotect"

    invoke-static {v4, v5, v0}, Lcom/dark/core/Syscall;->checkResultOrThrow(JLjava/lang/String;)V
    :try_end_d9
    .catch Landroid/system/ErrnoException; {:try_start_be .. :try_end_d9} :catch_dd
    .catchall {:try_start_be .. :try_end_d9} :catchall_e5

    .line 127
    .end local v4  # "rc":J
    nop

    .line 128
    :try_start_da
    sput-boolean v2, Lcom/dark/core/impl/NativeBridge;->sTrampolineSetReadOnly:Z

    goto :goto_e3

    .line 125
    :catch_dd
    move-exception v0

    .line 126
    .restart local v0  # "e":Landroid/system/ErrnoException;
    invoke-static {v0}, Lcom/dark/core/impl/ReflectHelper;->unsafeThrow(Ljava/lang/Throwable;)Ljava/lang/AssertionError;

    move-result-object v2

    throw v2
    :try_end_e3
    .catchall {:try_start_da .. :try_end_e3} :catchall_e5

    .line 131
    .end local v0  # "e":Landroid/system/ErrnoException;
    .end local v3  # "sysnr":Lcom/dark/core/impl/trampoline/ISyscallNumberTable;
    .end local v8  # "pageSize":J
    :cond_e3
    :goto_e3
    monitor-exit v1

    return-void

    .line 75
    :catchall_e5
    move-exception v0

    :try_start_e6
    monitor-exit v1
    :try_end_e7
    .catchall {:try_start_e6 .. :try_end_e7} :catchall_e5

    throw v0
.end method

.method public static native nativeCallPointerFunction0(J)J
.end method

.method public static native nativeCallPointerFunction1(JJ)J
.end method

.method public static native nativeCallPointerFunction2(JJJ)J
.end method

.method public static native nativeCallPointerFunction3(JJJJ)J
.end method

.method public static native nativeCallPointerFunction4(JJJJJ)J
.end method

.method public static native nativeClearCache(JJ)V
.end method

.method public static native nativeGetJavaVM()J
.end method

.method public static native nativeSyscall(IJJJJJJ)J
.end method
